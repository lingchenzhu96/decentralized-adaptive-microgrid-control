function [sys,x0,str,ts] = Scenario2_sfunc_controller(t,x,u,flag)
switch flag
  case 0
    [sys,x0,str,ts]=mdlInitializeSizes;

  case 1
    sys=mdlDerivatives(t,x,u);

  case 3
    sys=mdlOutputs(t,x,u);

    case 2
        sys=[];
    case 4
        sys=[];
  case 9
    sys=[];
  otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end

function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 10;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 21;
sizes.NumInputs      = 0;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed
sys = simsizes(sizes);

 x0  = [85;0;90;0;0;0;0;0;0;0];




str = [];
ts  = [0 0];
function sys=mdlDerivatives(t,x,u)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



Pcpl=100; 


if (t<=4)
R=50; 
 elseif (t>4 && t<8)
     R=25;
else 
R=50; 
end


L1=0.2;
L2=0.2;
C1=1;
C2=1;

Vin1=200;
Vin2=200;
d12=0.1*sin(4*t);
d22=0.1*sin(4*t);

kesai2=15;
lamta11=2;
lamta21=2;
kappa1=0.2;
kappa2=0.2;

L11=10; L12=500; L21=10; L22=500; r1=5; r2=5; tau=0.5; Tb=1; 
Ts=1;

rho10=40;
rho1Ts=12;
rho20=40;
rho2Ts=12;

sigma=exp(-0.01*t);
tau12=0.1; tau22=0.1;

KP10=500; KP20=500;
q1=0.1;q2=0.1;

vc1a=0;vc1b=150;
vc2a=0;vc2b=150;
dvc2a=0;dvc2b=0;

vc1rX=100;
vc1sr=100;
vc1srtau=100;
dvc1sr=0;
ddvc1sr=0;
dvc1srtau=0;
ddvc1srtau=0;

if (t<=4)
vc2rX=100;
dvc2rX=0; 
ddvc2rX=0; 
 elseif (t>4 && t<8)
       vc2rX=50;
       dvc2rX=0; 
       ddvc2rX=0; 
else 
 vc2rX=180;
       dvc2rX=0; 
       ddvc2rX=0; 
end

if (t<=4+tau)
vc2rXtau=100;
dvc2rXtau=0; 
ddvc2rXtau=0; 
 elseif (t>4+tau && t<8+tau)
       vc2rXtau=50;
       dvc2rXtau=0; 
      ddvc2rXtau=0; 
else 
 vc2rXtau=180;
       dvc2rXtau=0; 
       ddvc2rXtau=0; 
end


if vc2rX>(vc2b-kesai2)
vc2r=vc2b-kesai2;
dvc2r=0;
ddvc2r=0;
elseif vc2rX<(vc2a+kesai2)
vc2r=vc2a+kesai2;
dvc2r=0;
ddvc2r=0;
else
   vc2r= vc2rX;
dvc2r=0;
ddvc2r=0;
end

if vc2rXtau>(vc2b-kesai2)
vc2rtau=vc2b-kesai2;
dvc2rtau=0;
ddvc2rtau=0;
elseif vc2rXtau<(vc2a+kesai2)
vc2rtau=vc2a+kesai2;
dvc2rtau=0;
ddvc2rtau=0;
else
   vc2rtau= vc2rXtau;
dvc2rtau=0;
ddvc2rtau=0;
end


Tyr21=4;
Tyr22=8;

if (t<Tyr21-Tb)  
vc2sr=vc2r;
    dvc2sr=0;
        ddvc2sr=0;


elseif (t>=Tyr21-Tb && t<=Tyr21+Tb)
      t1a = Tyr21-Tb;
t1b = Tyr21+Tb;
y1a = 100;
y1b = 50;
dy1a = 0;
dy1b = 0;
ddy1a = 0;
ddy1b = 0;

s = (t - t1a) / (t1b - t1a);
h = t1b - t1a;  
h_inv = 1 / h;  


h00 = 1 - 10*s^3 + 15*s^4 - 6*s^5;
h10 = h * (s - 6*s^3 + 8*s^4 - 3*s^5);
h20 = h^2/2 * (s^2 - 3*s^3 + 3*s^4 - s^5);
h01 = 10*s^3 - 15*s^4 + 6*s^5;
h11 = h * (-4*s^3 + 7*s^4 - 3*s^5);
h21 = h^2/2 * (s^3 - 2*s^4 + s^5);


dh00 = h_inv * (-30*s^2 + 60*s^3 - 30*s^4);
dh10 = 1 - 18*s^2 + 32*s^3 - 15*s^4;
dh20 = h * (s - 9*s^2/2 + 6*s^3 - 5*s^4/2);
dh01 = h_inv * (30*s^2 - 60*s^3 + 30*s^4);
dh11 = -12*s^2 + 28*s^3 - 15*s^4;
dh21 = h * (3*s^2/2 - 4*s^3 + 5*s^4/2);


ddh00 = h_inv^2 * (-60*s + 180*s^2 - 120*s^3);
ddh10 = h_inv * (-36*s + 96*s^2 - 60*s^3);
ddh20 = 1 - 9*s + 18*s^2 - 10*s^3;
ddh01 = h_inv^2 * (60*s - 180*s^2 + 120*s^3);
ddh11 = h_inv * (-24*s + 84*s^2 - 60*s^3);
ddh21 = h_inv * (3*s - 12*s^2 + 10*s^3);

vc2sr = h00*y1a + h10*dy1a + h20*ddy1a + h01*y1b + h11*dy1b + h21*ddy1b;
dvc2sr = dh00*y1a + dh10*dy1a + dh20*ddy1a + dh01*y1b + dh11*dy1b + dh21*ddy1b;
ddvc2sr = ddh00*y1a + ddh10*dy1a + ddh20*ddy1a + ddh01*y1b + ddh11*dy1b + ddh21*ddy1b;


    
 elseif (t>=Tyr21+Tb && t<=Tyr22-Tb)
   vc2sr=vc2r;
    dvc2sr=0;
ddvc2sr=0;

elseif (t>=Tyr22-Tb && t<=Tyr22+Tb)
      t1a = Tyr22-Tb;
t1b = Tyr22+Tb;
y1a = 50;
y1b = vc2b-kesai2;
dy1a = 0;
dy1b = 0;
ddy1a = 0;
ddy1b = 0;

s = (t - t1a) / (t1b - t1a);
h = t1b - t1a;  
h_inv = 1 / h;  


h00 = 1 - 10*s^3 + 15*s^4 - 6*s^5;
h10 = h * (s - 6*s^3 + 8*s^4 - 3*s^5);
h20 = h^2/2 * (s^2 - 3*s^3 + 3*s^4 - s^5);
h01 = 10*s^3 - 15*s^4 + 6*s^5;
h11 = h * (-4*s^3 + 7*s^4 - 3*s^5);
h21 = h^2/2 * (s^3 - 2*s^4 + s^5);


dh00 = h_inv * (-30*s^2 + 60*s^3 - 30*s^4);
dh10 = 1 - 18*s^2 + 32*s^3 - 15*s^4;
dh20 = h * (s - 9*s^2/2 + 6*s^3 - 5*s^4/2);
dh01 = h_inv * (30*s^2 - 60*s^3 + 30*s^4);
dh11 = -12*s^2 + 28*s^3 - 15*s^4;
dh21 = h * (3*s^2/2 - 4*s^3 + 5*s^4/2);


ddh00 = h_inv^2 * (-60*s + 180*s^2 - 120*s^3);
ddh10 = h_inv * (-36*s + 96*s^2 - 60*s^3);
ddh20 = 1 - 9*s + 18*s^2 - 10*s^3;
ddh01 = h_inv^2 * (60*s - 180*s^2 + 120*s^3);
ddh11 = h_inv * (-24*s + 84*s^2 - 60*s^3);
ddh21 = h_inv * (3*s - 12*s^2 + 10*s^3);


vc2sr = h00*y1a + h10*dy1a + h20*ddy1a + h01*y1b + h11*dy1b + h21*ddy1b;
dvc2sr = dh00*y1a + dh10*dy1a + dh20*ddy1a + dh01*y1b + dh11*dy1b + dh21*ddy1b;
ddvc2sr = ddh00*y1a + ddh10*dy1a + ddh20*ddy1a + ddh01*y1b + ddh11*dy1b + ddh21*ddy1b;

else
   vc2sr=vc2b-kesai2;
    dvc2sr=0;
ddvc2sr=0;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (t<Tyr21+tau-Tb)  
vc2srtau=vc2rtau;
    dvc2srtau=0;
        ddvc2srtau=0;


elseif (t>=Tyr21-Tb+tau && t<=Tyr21+Tb+tau)
      t1a = Tyr21-Tb+tau;
t1b = Tyr21+Tb+tau;
y1a = 100;
y1b = 50;
dy1a = 0;
dy1b = 0;
ddy1a = 0;
ddy1b = 0;

s = (t - t1a) / (t1b - t1a);
h = t1b - t1a;  
h_inv = 1 / h; 


h00 = 1 - 10*s^3 + 15*s^4 - 6*s^5;
h10 = h * (s - 6*s^3 + 8*s^4 - 3*s^5);
h20 = h^2/2 * (s^2 - 3*s^3 + 3*s^4 - s^5);
h01 = 10*s^3 - 15*s^4 + 6*s^5;
h11 = h * (-4*s^3 + 7*s^4 - 3*s^5);
h21 = h^2/2 * (s^3 - 2*s^4 + s^5);


dh00 = h_inv * (-30*s^2 + 60*s^3 - 30*s^4);
dh10 = 1 - 18*s^2 + 32*s^3 - 15*s^4;
dh20 = h * (s - 9*s^2/2 + 6*s^3 - 5*s^4/2);
dh01 = h_inv * (30*s^2 - 60*s^3 + 30*s^4);
dh11 = -12*s^2 + 28*s^3 - 15*s^4;
dh21 = h * (3*s^2/2 - 4*s^3 + 5*s^4/2);


ddh00 = h_inv^2 * (-60*s + 180*s^2 - 120*s^3);
ddh10 = h_inv * (-36*s + 96*s^2 - 60*s^3);
ddh20 = 1 - 9*s + 18*s^2 - 10*s^3;
ddh01 = h_inv^2 * (60*s - 180*s^2 + 120*s^3);
ddh11 = h_inv * (-24*s + 84*s^2 - 60*s^3);
ddh21 = h_inv * (3*s - 12*s^2 + 10*s^3);


vc2srtau = h00*y1a + h10*dy1a + h20*ddy1a + h01*y1b + h11*dy1b + h21*ddy1b;
dvc2srtau = dh00*y1a + dh10*dy1a + dh20*ddy1a + dh01*y1b + dh11*dy1b + dh21*ddy1b;
ddvc2srtau = ddh00*y1a + ddh10*dy1a + ddh20*ddy1a + ddh01*y1b + ddh11*dy1b + ddh21*ddy1b;
    
 elseif (t>=Tyr21+Tb+tau && t<=Tyr22-Tb+tau)
   vc2srtau=vc2r;
    dvc2srtau=0;
ddvc2srtau=0;

elseif (t>=Tyr22-Tb+tau && t<=Tyr22+Tb+tau)
      t1a = Tyr22-Tb+tau;
t1b = Tyr22+Tb+tau;
y1a = 50;
y1b = vc2b-kesai2;
dy1a = 0;
dy1b = 0;
ddy1a = 0;
ddy1b = 0;

s = (t - t1a) / (t1b - t1a);
h = t1b - t1a;  
h_inv = 1 / h;  


h00 = 1 - 10*s^3 + 15*s^4 - 6*s^5;
h10 = h * (s - 6*s^3 + 8*s^4 - 3*s^5);
h20 = h^2/2 * (s^2 - 3*s^3 + 3*s^4 - s^5);
h01 = 10*s^3 - 15*s^4 + 6*s^5;
h11 = h * (-4*s^3 + 7*s^4 - 3*s^5);
h21 = h^2/2 * (s^3 - 2*s^4 + s^5);


dh00 = h_inv * (-30*s^2 + 60*s^3 - 30*s^4);
dh10 = 1 - 18*s^2 + 32*s^3 - 15*s^4;
dh20 = h * (s - 9*s^2/2 + 6*s^3 - 5*s^4/2);
dh01 = h_inv * (30*s^2 - 60*s^3 + 30*s^4);
dh11 = -12*s^2 + 28*s^3 - 15*s^4;
dh21 = h * (3*s^2/2 - 4*s^3 + 5*s^4/2);


ddh00 = h_inv^2 * (-60*s + 180*s^2 - 120*s^3);
ddh10 = h_inv * (-36*s + 96*s^2 - 60*s^3);
ddh20 = 1 - 9*s + 18*s^2 - 10*s^3;
ddh01 = h_inv^2 * (60*s - 180*s^2 + 120*s^3);
ddh11 = h_inv * (-24*s + 84*s^2 - 60*s^3);
ddh21 = h_inv * (3*s - 12*s^2 + 10*s^3);


vc2srtau = h00*y1a + h10*dy1a + h20*ddy1a + h01*y1b + h11*dy1b + h21*ddy1b;
dvc2srtau = dh00*y1a + dh10*dy1a + dh20*ddy1a + dh01*y1b + dh11*dy1b + dh21*ddy1b;
ddvc2srtau = ddh00*y1a + ddh10*dy1a + ddh20*ddy1a + ddh01*y1b + ddh11*dy1b + ddh21*ddy1b;

else
   vc2srtau=vc2b-kesai2;
    dvc2srtau=0;
ddvc2srtau=0;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


rho1b=x(9);
drho1b=-r1*x(9)+L11*tanh(L12*abs(dvc1sr-dvc1srtau)^2);

if t<Ts
rho1a=(rho10-t/Ts)*exp(1-Ts/(Ts-t))+rho1Ts;
drho1a=(-1/Ts)*exp(1-Ts/(Ts-t))+(rho10-t/Ts)*(-Ts/(Ts-t)^2)*exp(1-Ts/(Ts-t));
else
    rho1a=rho1Ts;
drho1a=0;
end
rho1= rho1a+ rho1b;
drho1= drho1a+ drho1b;


rho2b=x(10);
drho2b=-r2*x(10)+L21*tanh(L22*abs(dvc2sr-dvc2srtau)^2);





if t<Ts
rho2a=(rho20-t/Ts)*exp(1-Ts/(Ts-t))+rho2Ts;
drho2a=(-1/Ts)*exp(1-Ts/(Ts-t))+(rho20-t/Ts)*(-Ts/(Ts-t)^2)*exp(1-Ts/(Ts-t));
else
    rho2a=rho2Ts;
drho2a=0;
end
rho2= rho2a+ rho2b;
drho2= drho2a+ drho2b;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

epson11=x(1)-vc1sr;
depson11=x(2)-dvc1sr;
epson21=x(3)-vc2sr;
depson21=x(4)-dvc2sr;
omega1=lamta11*epson11+depson11;
omega2=lamta21*epson21+depson21;
zeta1=omega1/rho1;
zeta2=omega2/rho2;
z1=zeta1/(1-zeta1^2);
z2=zeta2/(1-zeta2^2);
beta1=(1+zeta1^2)/(rho1*(1-zeta1^2)^2);
beta2=(1+zeta2^2)/(rho1*(1-zeta2^2)^2);



fai1=abs((1/(C1*(x(1)^2))-1/(C1*R))*x(2))+abs(lamta11*depson11)+...
   abs(zeta1*drho1)+abs(kappa1*z1/beta1)+abs(ddvc1sr)+abs(x(1)/(L1*C1));
fai2=abs((1/(C2*(x(3)^2))-1/(C2*R))*x(4))+abs(lamta21*depson21)+...
   abs(zeta2*drho2)+abs(kappa2*z2/beta2)+abs(ddvc2sr)+abs(x(3)/(L2*C2));


E1=z1+kappa1*x(5);
E2=z2+kappa2*x(6);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

KP1=KP10/beta1;
KP2=KP20/beta2;

detaKP1=x(7)*(beta1*(fai1^2))/(((beta1*fai1*E1)^2+sigma^2)^(1/2));
detaKP2=x(8)*(beta2*(fai2^2))/(((beta2*fai2*E2)^2+sigma^2)^(1/2));



 h1=-(KP1+detaKP1)*E1;
 h2=-(KP2+detaKP2)*E2;




sys(1)=x(2);
sys(2)=h1+(Pcpl/(C1*(x(1)^2))-1/(C1*R))*x(2)+d12-x(1)/(L1*C1);
sys(3)=x(4);
sys(4)=h2+(Pcpl/(C2*(x(3)^2))-1/(C2*R))*x(4)+d22-x(3)/(L2*C2);
sys(5)=z1;
sys(6)=z2;
sys(7)=q1*((beta1*fai1*E1)^2)/(((beta1*fai1*E1)^2+sigma^2)^(1/2));
sys(8)=q2*((beta2*fai2*E2)^2)/(((beta1*fai2*E2)^2+sigma^2)^(1/2));
sys(9)=-r1*x(9)+L11*tanh(L12*abs(dvc1sr-dvc1srtau)^2);
sys(10)=-r2*x(10)+L21*tanh(L22*abs(dvc2sr-dvc2srtau)^2);












%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function sys=mdlOutputs(t,x,u)





Pcpl=100; 


if (t<=4)
R=50; 
 elseif (t>4 && t<8)
     R=25;
else 
R=50; 
end


L1=0.2;
L2=0.2;
C1=1;
C2=1;

Vin1=200;
Vin2=200;
d12=0.1*sin(4*t);
d22=0.1*sin(4*t);

kesai2=15;
lamta11=2;
lamta21=2;
kappa1=0.2;
kappa2=0.2;

L11=10; L12=500; L21=10; L22=500; r1=5; r2=5; tau=0.5; Tb=1; 
Ts=1;

rho10=40;
rho1Ts=12;
rho20=40;
rho2Ts=12;

sigma=exp(-0.01*t);
tau12=0.1; tau22=0.1;

KP10=500; KP20=500;
q1=0.1;q2=0.1;

vc1a=0;vc1b=150;
vc2a=0;vc2b=150;
dvc2a=0;dvc2b=0;

vc1rX=100;
vc1sr=100;
vc1srtau=100;
dvc1sr=0;
ddvc1sr=0;
dvc1srtau=0;
ddvc1srtau=0;

if (t<=4)
vc2rX=100;
dvc2rX=0; 
ddvc2rX=0; 
 elseif (t>4 && t<8)
       vc2rX=50;
       dvc2rX=0; 
       ddvc2rX=0; 
else 
 vc2rX=180;
       dvc2rX=0; 
       ddvc2rX=0; 
end

if (t<=4+tau)
vc2rXtau=100;
dvc2rXtau=0; 
ddvc2rXtau=0; 
 elseif (t>4+tau && t<8+tau)
       vc2rXtau=50;
       dvc2rXtau=0; 
      ddvc2rXtau=0; 
else 
 vc2rXtau=180;
       dvc2rXtau=0; 
       ddvc2rXtau=0; 
end


if vc2rX>(vc2b-kesai2)
vc2r=vc2b-kesai2;
dvc2r=0;
ddvc2r=0;
elseif vc2rX<(vc2a+kesai2)
vc2r=vc2a+kesai2;
dvc2r=0;
ddvc2r=0;
else
   vc2r= vc2rX;
dvc2r=0;
ddvc2r=0;
end

if vc2rXtau>(vc2b-kesai2)
vc2rtau=vc2b-kesai2;
dvc2rtau=0;
ddvc2rtau=0;
elseif vc2rXtau<(vc2a+kesai2)
vc2rtau=vc2a+kesai2;
dvc2rtau=0;
ddvc2rtau=0;
else
   vc2rtau= vc2rXtau;
dvc2rtau=0;
ddvc2rtau=0;
end


Tyr21=4;
Tyr22=8;

if (t<Tyr21-Tb)  
vc2sr=vc2r;
    dvc2sr=0;
        ddvc2sr=0;


elseif (t>=Tyr21-Tb && t<=Tyr21+Tb)
      t1a = Tyr21-Tb;
t1b = Tyr21+Tb;
y1a = 100;
y1b = 50;
dy1a = 0;
dy1b = 0;
ddy1a = 0;
ddy1b = 0;

s = (t - t1a) / (t1b - t1a);
h = t1b - t1a;  
h_inv = 1 / h;  


h00 = 1 - 10*s^3 + 15*s^4 - 6*s^5;
h10 = h * (s - 6*s^3 + 8*s^4 - 3*s^5);
h20 = h^2/2 * (s^2 - 3*s^3 + 3*s^4 - s^5);
h01 = 10*s^3 - 15*s^4 + 6*s^5;
h11 = h * (-4*s^3 + 7*s^4 - 3*s^5);
h21 = h^2/2 * (s^3 - 2*s^4 + s^5);


dh00 = h_inv * (-30*s^2 + 60*s^3 - 30*s^4);
dh10 = 1 - 18*s^2 + 32*s^3 - 15*s^4;
dh20 = h * (s - 9*s^2/2 + 6*s^3 - 5*s^4/2);
dh01 = h_inv * (30*s^2 - 60*s^3 + 30*s^4);
dh11 = -12*s^2 + 28*s^3 - 15*s^4;
dh21 = h * (3*s^2/2 - 4*s^3 + 5*s^4/2);


ddh00 = h_inv^2 * (-60*s + 180*s^2 - 120*s^3);
ddh10 = h_inv * (-36*s + 96*s^2 - 60*s^3);
ddh20 = 1 - 9*s + 18*s^2 - 10*s^3;
ddh01 = h_inv^2 * (60*s - 180*s^2 + 120*s^3);
ddh11 = h_inv * (-24*s + 84*s^2 - 60*s^3);
ddh21 = h_inv * (3*s - 12*s^2 + 10*s^3);

vc2sr = h00*y1a + h10*dy1a + h20*ddy1a + h01*y1b + h11*dy1b + h21*ddy1b;
dvc2sr = dh00*y1a + dh10*dy1a + dh20*ddy1a + dh01*y1b + dh11*dy1b + dh21*ddy1b;
ddvc2sr = ddh00*y1a + ddh10*dy1a + ddh20*ddy1a + ddh01*y1b + ddh11*dy1b + ddh21*ddy1b;


    
 elseif (t>=Tyr21+Tb && t<=Tyr22-Tb)
   vc2sr=vc2r;
    dvc2sr=0;
ddvc2sr=0;

elseif (t>=Tyr22-Tb && t<=Tyr22+Tb)
      t1a = Tyr22-Tb;
t1b = Tyr22+Tb;
y1a = 50;
y1b = vc2b-kesai2;
dy1a = 0;
dy1b = 0;
ddy1a = 0;
ddy1b = 0;

s = (t - t1a) / (t1b - t1a);
h = t1b - t1a;  
h_inv = 1 / h;  


h00 = 1 - 10*s^3 + 15*s^4 - 6*s^5;
h10 = h * (s - 6*s^3 + 8*s^4 - 3*s^5);
h20 = h^2/2 * (s^2 - 3*s^3 + 3*s^4 - s^5);
h01 = 10*s^3 - 15*s^4 + 6*s^5;
h11 = h * (-4*s^3 + 7*s^4 - 3*s^5);
h21 = h^2/2 * (s^3 - 2*s^4 + s^5);


dh00 = h_inv * (-30*s^2 + 60*s^3 - 30*s^4);
dh10 = 1 - 18*s^2 + 32*s^3 - 15*s^4;
dh20 = h * (s - 9*s^2/2 + 6*s^3 - 5*s^4/2);
dh01 = h_inv * (30*s^2 - 60*s^3 + 30*s^4);
dh11 = -12*s^2 + 28*s^3 - 15*s^4;
dh21 = h * (3*s^2/2 - 4*s^3 + 5*s^4/2);


ddh00 = h_inv^2 * (-60*s + 180*s^2 - 120*s^3);
ddh10 = h_inv * (-36*s + 96*s^2 - 60*s^3);
ddh20 = 1 - 9*s + 18*s^2 - 10*s^3;
ddh01 = h_inv^2 * (60*s - 180*s^2 + 120*s^3);
ddh11 = h_inv * (-24*s + 84*s^2 - 60*s^3);
ddh21 = h_inv * (3*s - 12*s^2 + 10*s^3);


vc2sr = h00*y1a + h10*dy1a + h20*ddy1a + h01*y1b + h11*dy1b + h21*ddy1b;
dvc2sr = dh00*y1a + dh10*dy1a + dh20*ddy1a + dh01*y1b + dh11*dy1b + dh21*ddy1b;
ddvc2sr = ddh00*y1a + ddh10*dy1a + ddh20*ddy1a + ddh01*y1b + ddh11*dy1b + ddh21*ddy1b;

else
   vc2sr=vc2b-kesai2;
    dvc2sr=0;
ddvc2sr=0;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (t<Tyr21+tau-Tb)  
vc2srtau=vc2rtau;
    dvc2srtau=0;
        ddvc2srtau=0;


elseif (t>=Tyr21-Tb+tau && t<=Tyr21+Tb+tau)
      t1a = Tyr21-Tb+tau;
t1b = Tyr21+Tb+tau;
y1a = 100;
y1b = 50;
dy1a = 0;
dy1b = 0;
ddy1a = 0;
ddy1b = 0;

s = (t - t1a) / (t1b - t1a);
h = t1b - t1a;  
h_inv = 1 / h; 


h00 = 1 - 10*s^3 + 15*s^4 - 6*s^5;
h10 = h * (s - 6*s^3 + 8*s^4 - 3*s^5);
h20 = h^2/2 * (s^2 - 3*s^3 + 3*s^4 - s^5);
h01 = 10*s^3 - 15*s^4 + 6*s^5;
h11 = h * (-4*s^3 + 7*s^4 - 3*s^5);
h21 = h^2/2 * (s^3 - 2*s^4 + s^5);


dh00 = h_inv * (-30*s^2 + 60*s^3 - 30*s^4);
dh10 = 1 - 18*s^2 + 32*s^3 - 15*s^4;
dh20 = h * (s - 9*s^2/2 + 6*s^3 - 5*s^4/2);
dh01 = h_inv * (30*s^2 - 60*s^3 + 30*s^4);
dh11 = -12*s^2 + 28*s^3 - 15*s^4;
dh21 = h * (3*s^2/2 - 4*s^3 + 5*s^4/2);


ddh00 = h_inv^2 * (-60*s + 180*s^2 - 120*s^3);
ddh10 = h_inv * (-36*s + 96*s^2 - 60*s^3);
ddh20 = 1 - 9*s + 18*s^2 - 10*s^3;
ddh01 = h_inv^2 * (60*s - 180*s^2 + 120*s^3);
ddh11 = h_inv * (-24*s + 84*s^2 - 60*s^3);
ddh21 = h_inv * (3*s - 12*s^2 + 10*s^3);


vc2srtau = h00*y1a + h10*dy1a + h20*ddy1a + h01*y1b + h11*dy1b + h21*ddy1b;
dvc2srtau = dh00*y1a + dh10*dy1a + dh20*ddy1a + dh01*y1b + dh11*dy1b + dh21*ddy1b;
ddvc2srtau = ddh00*y1a + ddh10*dy1a + ddh20*ddy1a + ddh01*y1b + ddh11*dy1b + ddh21*ddy1b;
    
 elseif (t>=Tyr21+Tb+tau && t<=Tyr22-Tb+tau)
   vc2srtau=vc2r;
    dvc2srtau=0;
ddvc2srtau=0;

elseif (t>=Tyr22-Tb+tau && t<=Tyr22+Tb+tau)
      t1a = Tyr22-Tb+tau;
t1b = Tyr22+Tb+tau;
y1a = 50;
y1b = vc2b-kesai2;
dy1a = 0;
dy1b = 0;
ddy1a = 0;
ddy1b = 0;

s = (t - t1a) / (t1b - t1a);
h = t1b - t1a;  
h_inv = 1 / h;  


h00 = 1 - 10*s^3 + 15*s^4 - 6*s^5;
h10 = h * (s - 6*s^3 + 8*s^4 - 3*s^5);
h20 = h^2/2 * (s^2 - 3*s^3 + 3*s^4 - s^5);
h01 = 10*s^3 - 15*s^4 + 6*s^5;
h11 = h * (-4*s^3 + 7*s^4 - 3*s^5);
h21 = h^2/2 * (s^3 - 2*s^4 + s^5);


dh00 = h_inv * (-30*s^2 + 60*s^3 - 30*s^4);
dh10 = 1 - 18*s^2 + 32*s^3 - 15*s^4;
dh20 = h * (s - 9*s^2/2 + 6*s^3 - 5*s^4/2);
dh01 = h_inv * (30*s^2 - 60*s^3 + 30*s^4);
dh11 = -12*s^2 + 28*s^3 - 15*s^4;
dh21 = h * (3*s^2/2 - 4*s^3 + 5*s^4/2);


ddh00 = h_inv^2 * (-60*s + 180*s^2 - 120*s^3);
ddh10 = h_inv * (-36*s + 96*s^2 - 60*s^3);
ddh20 = 1 - 9*s + 18*s^2 - 10*s^3;
ddh01 = h_inv^2 * (60*s - 180*s^2 + 120*s^3);
ddh11 = h_inv * (-24*s + 84*s^2 - 60*s^3);
ddh21 = h_inv * (3*s - 12*s^2 + 10*s^3);


vc2srtau = h00*y1a + h10*dy1a + h20*ddy1a + h01*y1b + h11*dy1b + h21*ddy1b;
dvc2srtau = dh00*y1a + dh10*dy1a + dh20*ddy1a + dh01*y1b + dh11*dy1b + dh21*ddy1b;
ddvc2srtau = ddh00*y1a + ddh10*dy1a + ddh20*ddy1a + ddh01*y1b + ddh11*dy1b + ddh21*ddy1b;

else
   vc2srtau=vc2b-kesai2;
    dvc2srtau=0;
ddvc2srtau=0;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


rho1b=x(9);
drho1b=-r1*x(9)+L11*tanh(L12*abs(dvc1sr-dvc1srtau)^2);

if t<Ts
rho1a=(rho10-t/Ts)*exp(1-Ts/(Ts-t))+rho1Ts;
drho1a=(-1/Ts)*exp(1-Ts/(Ts-t))+(rho10-t/Ts)*(-Ts/(Ts-t)^2)*exp(1-Ts/(Ts-t));
else
    rho1a=rho1Ts;
drho1a=0;
end
rho1= rho1a+ rho1b;
drho1= drho1a+ drho1b;


rho2b=x(10);
drho2b=-r2*x(10)+L21*tanh(L22*abs(dvc2sr-dvc2srtau)^2);





if t<Ts
rho2a=(rho20-t/Ts)*exp(1-Ts/(Ts-t))+rho2Ts;
drho2a=(-1/Ts)*exp(1-Ts/(Ts-t))+(rho20-t/Ts)*(-Ts/(Ts-t)^2)*exp(1-Ts/(Ts-t));
else
    rho2a=rho2Ts;
drho2a=0;
end
rho2= rho2a+ rho2b;
drho2= drho2a+ drho2b;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

epson11=x(1)-vc1sr;
depson11=x(2)-dvc1sr;
epson21=x(3)-vc2sr;
depson21=x(4)-dvc2sr;
omega1=lamta11*epson11+depson11;
omega2=lamta21*epson21+depson21;
zeta1=omega1/rho1;
zeta2=omega2/rho2;
z1=zeta1/(1-zeta1^2);
z2=zeta2/(1-zeta2^2);
beta1=(1+zeta1^2)/(rho1*(1-zeta1^2)^2);
beta2=(1+zeta2^2)/(rho1*(1-zeta2^2)^2);



fai1=abs((1/(C1*(x(1)^2))-1/(C1*R))*x(2))+abs(lamta11*depson11)+...
   abs(zeta1*drho1)+abs(kappa1*z1/beta1)+abs(ddvc1sr)+abs(x(1)/(L1*C1));
fai2=abs((1/(C2*(x(3)^2))-1/(C2*R))*x(4))+abs(lamta21*depson21)+...
   abs(zeta2*drho2)+abs(kappa2*z2/beta2)+abs(ddvc2sr)+abs(x(3)/(L2*C2));


E1=z1+kappa1*x(5);
E2=z2+kappa2*x(6);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

KP1=KP10/beta1;
KP2=KP20/beta2;

detaKP1=x(7)*(beta1*(fai1^2))/(((beta1*fai1*E1)^2+sigma^2)^(1/2));
detaKP2=x(8)*(beta2*(fai2^2))/(((beta2*fai2*E2)^2+sigma^2)^(1/2));



 h1=-(KP1+detaKP1)*E1;
 h2=-(KP2+detaKP2)*E2;



    sys(1)=omega1;
    sys(2)=rho1;
    sys(3)=-rho1;
    sys(4)=omega2;
    sys(5)=rho2;
    sys(6)=-rho2;
    
    sys(7)=x(1);
    sys(8)=vc1rX;
    sys(9)=vc1a;
    sys(10)=vc1b;
    sys(11)=vc1sr;
    
    sys(12)=x(3);
    sys(13)=vc2rX;
    sys(14)=vc2a;
    sys(15)=vc2b;
    sys(16)=vc2r;
    sys(17)=vc2sr;
    
    sys(18)=h1;
    sys(19)=h2;
    
    sys(20)=x(7);
    sys(21)=x(8);
   







