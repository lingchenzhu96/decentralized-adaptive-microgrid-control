





figure('color','white');
plot(a.time,a.signals.values(:,9),'r-','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,7),'b-','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,8),'c--','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,12),'m-','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,13),'g--','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,10),'r-.','LineWidth',2);hold on;
axis([0 12 -100 300]);
xlabel('Time (s)','FontSize',20);
h=legend('$v_{Cia}$','$v_{C1}$','$v_{C1r}^{\ast }$','$v_{C2}$','$v_{C2r}^{\ast }$','$v_{Cib}$');
set(gca,'FontName','Helvetica','FontSize',20);
set(h,'Interpreter','latex','FontSize',14);


figure('color','white');
plot(a.time, a.signals.values(:,7) - a.signals.values(:,11), 'r-', 'LineWidth', 2);hold on;
plot(a.time, a.signals.values(:,12) - a.signals.values(:,17), 'b--', 'LineWidth', 2);hold on;
axis([0 12 -15 5]);
xlabel('Time (s)','FontSize',20);
h=legend('$\varepsilon_{11}$','$\varepsilon_{21}$');
set(gca,'FontName','Helvetica','FontSize',20);
set(h,'Interpreter','latex','FontSize',20);




