





figure('color','white');
plot(a.time,a.signals.values(:,9),'r-','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,7),'m-','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,8),'c-.','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,8),'b-.','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,11),'g--','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,10),'r-.','LineWidth',2);hold on;
axis([0 12 -100 300]);
xlabel('Time (s)','FontSize',20);
h=legend('$v_{C1a}$','$v_{C1}$','$v_{C1r}^{\ast }$','$v_{C2r}$','$v_{C1sr}$','$v_{C1b}$');
set(gca,'FontName','Helvetica','FontSize',20);
set(h,'Interpreter','latex','FontSize',14);




figure('color','white');
plot(a.time,a.signals.values(:,14),'r-','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,12),'m-','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,13),'c-.','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,16),'b--','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,17),'g--','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,15),'r-.','LineWidth',2);hold on;
axis([0 12 -100 300]);
xlabel('Time (s)','FontSize',20);
h=legend('$v_{C2a}$','$v_{C2}$','$v_{C2r}^{\ast }$','$v_{C2r}$','$v_{C2sr}$','$v_{C2b}$');
set(gca,'FontName','Helvetica','FontSize',20);
set(h,'Interpreter','latex','FontSize',14);









figure('color','white');
plot(a.time,a.signals.values(:,2),'m-.','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,1),'b-','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,3),'r-.','LineWidth',2);hold on;
axis([0 12 -60 60]);
xlabel('Time (s)','FontSize',20);
h=legend('$\rho_{1}$','$\omega_{1}$','$-\rho_{1}$');
set(gca,'FontName','Helvetica','FontSize',20);
set(h,'Interpreter','latex','FontSize',20);



figure('color','white');
plot(a.time,a.signals.values(:,5),'m-.','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,4),'b-','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,6),'r-.','LineWidth',2);hold on;
axis([0 12 -60 60]);
xlabel('Time (s)','FontSize',20);
h=legend('$\rho_{2}$','$\omega_{2}$','$-\rho_{2}$');
set(gca,'FontName','Helvetica','FontSize',20);
set(h,'Interpreter','latex','FontSize',20);






figure('color','white');
plot(a.time,a.signals.values(:,20),'r-','LineWidth',2);hold on;
plot(a.time,a.signals.values(:,21),'b--','LineWidth',2);hold on;
axis([0 12 0 1.5]);
xlabel('Time (s)','FontSize',20);
h=legend('$\hat{\theta}_{1}$','$\hat{\theta}_{2}$');
set(gca,'FontName','Helvetica','FontSize',20);
set(h,'Interpreter','latex','FontSize',20);







figure('color','white');
plot(a.time,a.signals.values(:,18),'r-','LineWidth',2);hold on;
axis([0 12 0 1500]);
xlabel('Time (s)','FontSize',20);
h=legend('$u_{1}$');
set(gca,'FontName','Helvetica','FontSize',20);
set(h,'Interpreter','latex','FontSize',20);


figure('color','white');
plot(a.time,a.signals.values(:,19),'b-','LineWidth',2);hold on;
axis([0 12 0 1500]);
xlabel('Time (s)','FontSize',20);
h=legend('$u_{2}$');
set(gca,'FontName','Helvetica','FontSize',20);
set(h,'Interpreter','latex','FontSize',20);




figure('color','white');
plot(a.time, a.signals.values(:,7) - a.signals.values(:,11), 'r-', 'LineWidth', 2);hold on;
plot(a.time, a.signals.values(:,12) - a.signals.values(:,17), 'b--', 'LineWidth', 2);hold on;
axis([0 12 -15 5]);
xlabel('Time (s)','FontSize',20);
h=legend('$\varepsilon_{11}$','$\varepsilon_{21}$');
set(gca,'FontName','Helvetica','FontSize',20);
set(h,'Interpreter','latex','FontSize',20);

figure('color','white');
subplot(2,1,1);
plot(a.time, a.signals.values(:,22), 'r-', 'LineWidth', 2); hold on;
plot(a.time, a.signals.values(:,23), 'g-', 'LineWidth', 2); hold on;
plot(a.time, a.signals.values(:,24), 'b-', 'LineWidth', 2); hold on;
xlabel('Time (s)','FontSize',20);
ylabel('Error Metrics','FontSize',20);
title('Subsystem 1 (v_{C1}) Performance Indicators','FontSize',16);
h1 = legend('MSE', 'MAE', 'RMSE');
set(gca,'FontName','Helvetica','FontSize',16);
set(h1,'Interpreter','latex','FontSize',14);
grid on;

subplot(2,1,2);
plot(a.time, a.signals.values(:,25), 'r-', 'LineWidth', 2); hold on;
plot(a.time, a.signals.values(:,26), 'g-', 'LineWidth', 2); hold on;
plot(a.time, a.signals.values(:,27), 'b-', 'LineWidth', 2); hold on;
xlabel('Time (s)','FontSize',20);
ylabel('Error Metrics','FontSize',20);
title('Subsystem 2 (v_{C2}) Performance Indicators','FontSize',16);
h2 = legend('MSE', 'MAE', 'RMSE');
set(gca,'FontName','Helvetica','FontSize',16);
set(h2,'Interpreter','latex','FontSize',14);
grid on;


figure('color','white');
subplot(2,1,1);
plot(a.time, a.signals.values(:,28), 'm-', 'LineWidth', 2); hold on;
plot(a.time, a.signals.values(:,30), 'c-', 'LineWidth', 2); hold on;

final_os1 = a.signals.values(end,28);
final_ts1 = a.signals.values(end,30);
plot(a.time(end), final_os1, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
plot(a.time(end), final_ts1, 'bo', 'MarkerSize', 8, 'MarkerFaceColor', 'b');
xlabel('Time (s)','FontSize',20);
ylabel('Value','FontSize',20);
title('Subsystem 1 (v_{C1}) Transient Performance','FontSize',16);
legend('Overshoot (%)', 'Settling Time (s)', 'Final OS', 'Final TS', 'Location', 'best');
set(gca,'FontName','Helvetica','FontSize',16);
grid on;

subplot(2,1,2);
plot(a.time, a.signals.values(:,29), 'm-', 'LineWidth', 2); hold on;
plot(a.time, a.signals.values(:,31), 'c-', 'LineWidth', 2); hold on;

final_os2 = a.signals.values(end,29);
final_ts2 = a.signals.values(end,31);
plot(a.time(end), final_os2, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
plot(a.time(end), final_ts2, 'bo', 'MarkerSize', 8, 'MarkerFaceColor', 'b');
xlabel('Time (s)','FontSize',20);
ylabel('Value','FontSize',20);
title('Subsystem 2 (v_{C2}) Transient Performance','FontSize',16);
legend('Overshoot (%)', 'Settling Time (s)', 'Final OS', 'Final TS', 'Location', 'best');
set(gca,'FontName','Helvetica','FontSize',16);
grid on;


figure('color','white');
subplot(2,1,1);
plot(a.time, a.signals.values(:,7), 'b-', 'LineWidth', 2); hold on;  % v_C1
plot(a.time, a.signals.values(:,11), 'r--', 'LineWidth', 2); hold on; % v_C1sr
% 
if final_os1 > 0
    [max_os1, max_idx1] = max(a.signals.values(:,7));
    plot(a.time(max_idx1), max_os1, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    text(a.time(max_idx1), max_os1, sprintf('  OS=%.2f%%', final_os1), 'FontSize', 12);
end
% 
if final_ts1 > 0
    plot(final_ts1, a.signals.values(find(a.time >= final_ts1, 1), 7), 'gs', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
    text(final_ts1, a.signals.values(find(a.time >= final_ts1, 1), 7), sprintf('  T_s=%.3fs', final_ts1), 'FontSize', 12);
end
xlabel('Time (s)','FontSize',20);
ylabel('Voltage (V)','FontSize',20);
title('Subsystem 1: v_{C1} Response with Performance Markers','FontSize',16);
legend('v_{C1}', 'v_{C1sr}', 'Overshoot', 'Settling Time', 'Location', 'best');
set(gca,'FontName','Helvetica','FontSize',16);
grid on;

subplot(2,1,2);
plot(a.time, a.signals.values(:,12), 'b-', 'LineWidth', 2); hold on;  % v_C2
plot(a.time, a.signals.values(:,17), 'r--', 'LineWidth', 2); hold on; % v_C2sr
% 
if final_os2 > 0
    [max_os2, max_idx2] = max(a.signals.values(:,12));
    plot(a.time(max_idx2), max_os2, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    text(a.time(max_idx2), max_os2, sprintf('  OS=%.2f%%', final_os2), 'FontSize', 12);
end
% 
if final_ts2 > 0
    plot(final_ts2, a.signals.values(find(a.time >= final_ts2, 1), 12), 'gs', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
    text(final_ts2, a.signals.values(find(a.time >= final_ts2, 1), 12), sprintf('  T_s=%.3fs', final_ts2), 'FontSize', 12);
end
xlabel('Time (s)','FontSize',20);
ylabel('Voltage (V)','FontSize',20);
title('Subsystem 2: v_{C2} Response with Performance Markers','FontSize',16);
legend('v_{C2}', 'v_{C2sr}', 'Overshoot', 'Settling Time', 'Location', 'best');
set(gca,'FontName','Helvetica','FontSize',16);
grid on;

% 
fprintf('\n=== Final Performance Indicators ===\n');
fprintf('Subsystem 1 (v_C1 tracking):\n');
fprintf('  MSE:  %.6f V?\n', a.signals.values(end,22));
fprintf('  MAE:  %.6f V\n', a.signals.values(end,23));
fprintf('  RMSE: %.6f V\n', a.signals.values(end,24));
fprintf('  Maximum Overshoot: %.2f%%\n', a.signals.values(end,28));
fprintf('  Settling Time: %.3f s\n', a.signals.values(end,30));

fprintf('\nSubsystem 2 (v_C2 tracking):\n');
fprintf('  MSE:  %.6f V?\n', a.signals.values(end,25));
fprintf('  MAE:  %.6f V\n', a.signals.values(end,26));
fprintf('  RMSE: %.6f V\n', a.signals.values(end,27));
fprintf('  Maximum Overshoot: %.2f%%\n', a.signals.values(end,29));
fprintf('  Settling Time: %.3f s\n', a.signals.values(end,31));

% 
fprintf('\n=== Performance Summary Table ===\n');
fprintf('%-25s %-15s %-15s\n', 'Performance Indicator', 'Subsystem 1', 'Subsystem 2');
fprintf('%-25s %-15s %-15s\n', repmat('-', 1, 55), repmat('-', 1, 15), repmat('-', 1, 15));
fprintf('%-25s %-15.6f %-15.6f\n', 'MSE (V?)', a.signals.values(end,22), a.signals.values(end,25));
fprintf('%-25s %-15.6f %-15.6f\n', 'MAE (V)', a.signals.values(end,23), a.signals.values(end,26));
fprintf('%-25s %-15.6f %-15.6f\n', 'RMSE (V)', a.signals.values(end,24), a.signals.values(end,27));
fprintf('%-25s %-15.2f %-15.2f\n', 'Overshoot (%)', a.signals.values(end,28), a.signals.values(end,29));
fprintf('%-25s %-15.3f %-15.3f\n', 'Settling Time (s)', a.signals.values(end,30), a.signals.values(end,31));

